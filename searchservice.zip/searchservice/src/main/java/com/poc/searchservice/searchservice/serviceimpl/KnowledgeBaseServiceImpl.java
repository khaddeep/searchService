package com.poc.searchservice.searchservice.serviceimpl;

import com.poc.searchservice.searchservice.service.EncodingService;
import com.poc.searchservice.searchservice.service.KnowledgeBaseService;
import dev.langchain4j.data.document.Document;
import dev.langchain4j.data.document.splitter.DocumentSplitters;
import dev.langchain4j.data.segment.TextSegment;
import dev.langchain4j.model.embedding.AllMiniLmL6V2EmbeddingModel;
import dev.langchain4j.model.embedding.E5SmallV2EmbeddingModel;
import io.milvus.client.MilvusServiceClient;
import io.milvus.grpc.*;
import io.milvus.param.*;
import io.milvus.param.collection.*;
import io.milvus.param.dml.InsertParam;
import io.milvus.param.index.CreateIndexParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@Service
public class KnowledgeBaseServiceImpl implements KnowledgeBaseService {

    @Value("${dimension}")
    public int dim;
    @Value("${collection.name}")
    public String collectionName;
    @Value("${maxSegmentSizeInChars}")
    public int maxSegmentSizeInChars = 200;
    @Value("${maxDocTextLength}")
    public int maxDocTextLength = 2000;
    @Value("${maxOverlapSizeInTokens}")
    public int maxOverlapSizeInTokens = 50;

    long documentId = 1;

    @Autowired
    private MilvusServiceClient milvusServiceClient;

    @Autowired
    private EncodingService encodingService;

    @Override
    public ResponseEntity<String> connectivity(String collectionName) {
        System.out.println("Connected to DB ");
        return new ResponseEntity<>(milvusServiceClient.checkHealth().toString(), HttpStatus.OK);
    }

    @Override
    public DescribeCollectionResponse describeCollectionResponse() {
        R<DescribeCollectionResponse> responseR = milvusServiceClient
                .describeCollection(DescribeCollectionParam
                        .newBuilder()
                        .withCollectionName(collectionName)
                        .build());

        return responseR.getData();
    }

    @Override
    public void createIndex(int waitIntervalInMilliSeconds, int timeOutInSeconds, String fieldName, String collectionName) {

    }

    @Override
    public void upsert(String text) {

//         Check if the collection exists
        if (describeCollectionResponse() != null) {
            milvusServiceClient.dropCollection(DropCollectionParam.newBuilder().withCollectionName(collectionName).build());
            System.out.println("Dropped Collection:" + collectionName);
        }


        // create a collection with customized primary field: doc_id_field
        FieldType id = FieldType.newBuilder()
                .withName("sys_id")
                .withDataType(DataType.Int64)
                .withPrimaryKey(true)
                .withAutoID(true)
                .build();
        FieldType docId = FieldType.newBuilder()
                .withName("doc_id")
                .withDataType(DataType.Int64)
                .withAutoID(false)
                .build();
        FieldType docText = FieldType.newBuilder()
                .withName("doc_text")
                .withDataType(DataType.VarChar)
                .withMaxLength(maxDocTextLength)
                .withDimension(dim)
                .build();
        FieldType docVector = FieldType.newBuilder()
                .withName("doc_text_vector")
                .withDataType(DataType.FloatVector)
                .withDimension(dim)
                .build();

        CreateCollectionParam createCollectionParam = CreateCollectionParam.newBuilder()
                .withCollectionName(collectionName)
                .withDescription("Document Knowledge Base")
                .withShardsNum(2)
                .addFieldType(id)
                .addFieldType(docId)
                .addFieldType(docText)
                .addFieldType(docVector)
                .build();

        System.out.println("Creating example collection: " + collectionName);
        System.out.println("Schema: " + createCollectionParam);
        milvusServiceClient.createCollection(createCollectionParam);
        System.out.println("Success!");


        List<Long> doc_id_array = new ArrayList<>();
        List<List<Float>> doc_text_vector_array = new ArrayList<>();
        List<String> doc_text_array = new ArrayList<>();

        String cleanText = text.replaceAll("[^ $&:.,!()'\"/a-zA-Z0-9]", "").replaceAll("  ", "");


        List<TextSegment> chunks = DocumentSplitters
                .recursive(maxSegmentSizeInChars, maxOverlapSizeInTokens)
                .split(Document.document(cleanText));

        List<InsertParam.Field> fields = new ArrayList<>();

        for (TextSegment chunk : chunks) {
            TextSegment textSegment = TextSegment.from(chunk.text());

            doc_text_vector_array.add(encodingService.encode(new AllMiniLmL6V2EmbeddingModel(), textSegment));
            doc_id_array.add(documentId);
            doc_text_array.add(textSegment.text());

            fields.add(new InsertParam.Field(docId.getName(), doc_id_array));
            fields.add(new InsertParam.Field(docVector.getName(), doc_text_vector_array));
            fields.add(new InsertParam.Field(docText.getName(), doc_text_array));
        }

        try {
            System.out.println("Inside Try Block::::");
            InsertParam insertParam = InsertParam.newBuilder()
                    .withCollectionName(collectionName)
                    .withFields(fields)
                    .build();
            milvusServiceClient.insert(insertParam);
        } catch (Exception exception) {
            System.out.println("Inside Catch Block::::");
            System.out.println("Message::::" + exception.getMessage());
            exception.printStackTrace();
        }

        documentId++;
        System.out.println("Successfully Populated and document ID is::::" + documentId);

//        // flush data
//        System.out.println("Flushing...");
//        flush(100, 90);
//        System.out.println("Flushed");

////         build index
        System.out.println("Building AutoIndex...");
        final IndexType INDEX_TYPE = IndexType.AUTOINDEX;   // IndexType
        createIndex(milvusServiceClient, collectionName, docVector, INDEX_TYPE);

        // load collection
        System.out.println("Loading collection...");
        load();
    }

    private void load() {
        milvusServiceClient.loadCollection(LoadCollectionParam.newBuilder()
                .withCollectionName(collectionName)
                .withSyncLoad(true)
                .withSyncLoadWaitingInterval(2000L)
                .withSyncLoadWaitingTimeout(300L)
                .build());
    }

    @Override
    public void flush(long waitIntervalInMilliSeconds, long timeOutInSeconds) {
        milvusServiceClient.flush(FlushParam.newBuilder()
                .withCollectionNames(Collections.singletonList(collectionName))
                .withSyncFlush(true)
                .withSyncFlushWaitingInterval(waitIntervalInMilliSeconds)
                .withSyncFlushWaitingTimeout(timeOutInSeconds)
                .build());
    }

    private static void createIndex(MilvusServiceClient milvusClient, String collectionName, FieldType bookIntroField, IndexType INDEX_TYPE) {
        milvusClient.createIndex(
                CreateIndexParam.newBuilder()
                        .withCollectionName(collectionName)
                        .withFieldName(bookIntroField.getName())
                        .withIndexType(INDEX_TYPE)
                        .withMetricType(MetricType.COSINE)
                        .withSyncMode(Boolean.TRUE)
                        .withSyncWaitingInterval(500L)
                        .withSyncWaitingTimeout(30L)
                        .build());
    }

}
