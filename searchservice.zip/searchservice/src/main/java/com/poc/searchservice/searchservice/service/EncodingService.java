package com.poc.searchservice.searchservice.service;

import dev.langchain4j.data.segment.TextSegment;
import dev.langchain4j.model.embedding.EmbeddingModel;

import java.util.List;

public interface EncodingService {

    /**
     * Converts text to vector
     * @param embeddingModel embedding model
     * @param text knowledge or user query
     * @return vectors as a list
     */
    List<Float> encode(EmbeddingModel embeddingModel, String text);

    /**
     * Converts text to vector
     * @param embeddingModel embedding model
     * @param textsegement knowledge or user query
     * @return vectors as a list
     */
    List<Float> encode(EmbeddingModel embeddingModel, TextSegment textSegment);
}
