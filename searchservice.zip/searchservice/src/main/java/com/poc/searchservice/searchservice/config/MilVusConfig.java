package com.poc.searchservice.searchservice.config;

import io.milvus.client.MilvusServiceClient;
import io.milvus.param.ConnectParam;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class MilVusConfig {

    String uri = "https://in01-f0cdc49d8295a7f.az-eastus.vectordb.zillizcloud.com:19530";
    String user = "db_admin";
    String password = "H@thi143";

    @Bean
    public  MilvusServiceClient milvusServiceClient(){
//        final MilvusServiceClient milvusClient = new MilvusServiceClient(
//                ConnectParam.newBuilder()
//                        .withUri(uri)
//                        .withAuthorization(user, password)
//                        .build());

    final MilvusServiceClient milvusClient = new MilvusServiceClient(
            ConnectParam.newBuilder()
                    .withHost("localhost")
                    .withPort(19530)
                    .build()
    );
        return milvusClient;
    }

}
