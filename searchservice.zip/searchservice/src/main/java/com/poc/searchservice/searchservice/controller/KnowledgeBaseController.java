package com.poc.searchservice.searchservice.controller;

import com.poc.searchservice.searchservice.service.KnowledgeBaseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping(value = "/searchService/knowledgeBase")
public class KnowledgeBaseController {

    @Autowired
    private KnowledgeBaseService knowledgeBaseService;

    @PostMapping("/connectivity")
    public ResponseEntity<String> connectionCheck() throws InterruptedException {

        return knowledgeBaseService
                .connectivity("e5Small_document");
    }


    @PostMapping("/upsert")
    public String upsert(@RequestBody String text) {
        knowledgeBaseService.upsert(text);
        return "Completed";
    }


}
