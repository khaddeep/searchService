package com.poc.searchservice.searchservice.ResponseModel;

public class SearchData {

    private Long sysId;
    private Float score;
    private Long doc_id;
    private String doc_text;

    public Long getSysId() {
        return sysId;
    }

    public void setSysId(Long sysId) {
        this.sysId = sysId;
    }


    public Float getScore() {
        return score;
    }

    public void setScore(Float score) {
        this.score = score;
    }

    public Long getDoc_id() {
        return doc_id;
    }

    public void setDoc_id(Long doc_id) {
        this.doc_id = doc_id;
    }

    public String getDoc_text() {
        return doc_text;
    }

    public void setDoc_text(String doc_text) {
        this.doc_text = doc_text;
    }

    @Override
    public String toString() {
        return "SearchData{" +
                "sys_id=" + sysId +
                ", score=" + score +
                ", doc_id=" + doc_id +
                ", doc_text='" + doc_text + '\'' +
                '}';
    }
}
